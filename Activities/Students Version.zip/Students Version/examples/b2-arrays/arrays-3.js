// Example 1
{
  const arr = ['A', 'B', 'C'];
  console.log(arr[0]);

  // Replace value of first element in array
  arr[0] = 'Z';

  console.log(arr[0]);
}

// Example 2
{
  const arr = [4, 9, 16, 25];
  console.log(arr);
  arr.push(36, 49, 64, 81);
  console.log(arr);
}
