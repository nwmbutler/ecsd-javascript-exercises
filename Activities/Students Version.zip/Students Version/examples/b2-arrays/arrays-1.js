const arrA = [1, 2, 3];
const arrB = new Array(1, 2, 3);
const arrC = new Array(3);

console.log(arrA);
console.log(arrB);
console.log(arrC);
