// Example 1
{
  const arr = [1, 1, 2, 3, 5, 8];
  console.log("Array length: " + arr.length);
}

// Example 2
{
  const arr = ['One', 'Two', 'Three'];
  console.log(arr[2]);
}
