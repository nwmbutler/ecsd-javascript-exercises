const storeItem = {
	name: "apple",
	price: 0.89,
	inStock: true
};

// Access values
console.log("Name: " + storeItem.name);
console.log("Price: £" + storeItem['price']);
