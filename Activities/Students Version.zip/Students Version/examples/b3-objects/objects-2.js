const name = "JoJo";

// ES5
const es5 = {
    name: name
};

// ES6
const es6 = {
    name
};

console.log("ES5 definition: " + es5.name);
console.log("ES6 definition: " + es6.name);
