// Example 1
{
  const fruit = 'apple';

  function fruitAlert () {
      console.log(fruit);
  }

  fruitAlert();
}

// Example 2
{
  function pickFruit () {
      const fruit = 'apple';
  }

  console.log(fruit);
}
