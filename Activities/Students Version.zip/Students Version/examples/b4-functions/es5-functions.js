// First Function Declaration
function add(number1, number2) {
  return number1 + number2;
}

// Function Assignment
const multiply = function(number1, number2) {
  return number1 * number2;
}

// Calling Functions
const sum = add(10, 10);
const product = multiply(10, 10);

// Output to Console
console.log(sum);
console.log(product);
