// Declaration
const add = (number1, number2) => {
  return number1 + number2;
}

// Sinlge Line Short hand
const multiply = (number1, number2) => number1 * number2;

// Calling Functions
const sum = add(15, 10);
const product = multiply(15, 10);

// Output to Console
console.log(sum);
console.log(product);
