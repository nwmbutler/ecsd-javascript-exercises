// What types of variables are these?

let a = "?";
let b = 10;
let c = {};
let d = false;
let e = Infinity;
let f = undefined;
