// Set a to a random integer from 1 to 1000

let a = undefined;

console.log("Random number from 1 to 1000 -> " + a);
