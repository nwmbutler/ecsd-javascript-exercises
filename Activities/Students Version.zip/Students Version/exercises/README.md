# JavaScript Exercises

This is repository storing the necessary exercises to attempt in parallel with the JavaScript Training section in the Training Academy.
