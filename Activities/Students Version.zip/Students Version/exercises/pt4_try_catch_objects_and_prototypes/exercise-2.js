// What's so special about finally?

try {

} catch (error) {

} finally {

}
