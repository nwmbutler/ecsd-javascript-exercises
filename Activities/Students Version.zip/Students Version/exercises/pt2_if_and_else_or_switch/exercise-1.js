// Conditions

let colour = "green";
