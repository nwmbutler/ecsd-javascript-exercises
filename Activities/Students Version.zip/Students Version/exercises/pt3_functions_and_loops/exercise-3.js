// Shuffle the array

let array = []
for (let i = 1; i <= 25; i++) {
  array.push(i);
}
console.log("Standard array: " + array);

// Your function...

// let shuffledArray = shuffle(array);
console.log("Shuffled array: " + shuffledArray);
