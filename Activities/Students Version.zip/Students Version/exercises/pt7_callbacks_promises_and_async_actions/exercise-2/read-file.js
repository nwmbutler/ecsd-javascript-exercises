// Should read from file which is passed in execution of file
