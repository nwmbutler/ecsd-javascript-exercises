const a = 20;
let b = 25;
