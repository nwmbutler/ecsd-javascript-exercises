f = (name) => `Hello ${name}`;
